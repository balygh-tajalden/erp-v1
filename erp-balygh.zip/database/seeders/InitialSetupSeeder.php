<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class InitialSetupSeeder extends Seeder
{
    public function run()
    {
        // 1. Create Admin User (tblUsers)
        DB::table('tblUsers')->insertOrIgnore([
            [
                'ID' => 1,
                'UserName' => 'admin',
                'UserPassword' => Hash::make('admin123'), // Default password
                'IsActive' => 1,
                'BranchID' => 2, // Main Branch
                'CreatedDate' => now(),
                'CreatedBy' => 1,
            ]
        ]);

        // 2. Create Initial Session (tblsessions)
        DB::table('tblsessions')->insertOrIgnore([
            [
                'ID' => 1,
                'StartTime' => '2026-01-01 00:00:00',
                'IsEnded' => 0,
                'BranchID' => 2,
                'UserID' => 1,
            ]
        ]);

        // 3. Initial Currency Prices (tblCurrenciesPrices)
        // YER (1) is base. SAR (2) and USD (3)
        DB::table('tblCurrenciesPrices')->insertOrIgnore([
            [
                'SourceCurrencyID' => 2, // SAR
                'TargetCurrencyID' => 1, // YER
                'ExchangePrice' => 140.00,
                'BuyPrice' => 140.00,
                'SellPrice' => 141.00,
                'BranchID' => 2,
                'CreatedBy' => 1,
                'CreatedDate' => now(),
            ],
            [
                'SourceCurrencyID' => 3, // USD
                'TargetCurrencyID' => 1, // YER
                'ExchangePrice' => 530.00,
                'BuyPrice' => 530.00,
                'SellPrice' => 535.00,
                'BranchID' => 2,
                'CreatedBy' => 1,
                'CreatedDate' => now(),
            ]
        ]);
    }
}
