<?php

namespace Database\Seeders;

use App\Models\ServiceProvider;
use Illuminate\Database\Seeder;

class ServiceProvidersSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $providers = [
            // 1. شحن رصيد (Top-up)
            [
                'Name' => 'يمن موبايل رصيد',
                'Prefixes' => '77,78',
                'Code' => 'ym_topup',
                'Category' => 'Top-up',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],
            [
                'Name' => 'سبأفون رصيد',
                'Prefixes' => '71',
                'Code' => 'sf_topup',
                'Category' => 'Top-up',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],
            [
                'Name' => 'يو رصيد (YOU)',
                'Prefixes' => '73',
                'Code' => 'you_topup',
                'Category' => 'Top-up',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],
            [
                'Name' => 'واي رصيد (Y)',
                'Prefixes' => '70',
                'Code' => 'y_topup',
                'Category' => 'Top-up',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],

            // 2. سداد باقات (Bundles)
            [
                'Name' => 'باقات يمن موبايل',
                'Prefixes' => '77,78',
                'Code' => 'ym_bundles',
                'Category' => 'Bundles',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],
            [
                'Name' => 'باقات سبأفون',
                'Prefixes' => '71',
                'Code' => 'sf_bundles',
                'Category' => 'Bundles',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],

            // 3. الإنترنت والهاتف الثابت
            [
                'Name' => 'تسديد هاتف ثابت',
                'Prefixes' => '01',
                'Code' => 'landline_bill',
                'Category' => 'Internet & Landline',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],
            [
                'Name' => 'إنترنت ADSL',
                'Prefixes' => '01',
                'Code' => 'adsl_topup',
                'Category' => 'Internet & Landline',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],

            // 4. خدمات يمن فورجي
            [
                'Name' => 'يمن فورجي (تجديد)',
                'Prefixes' => '10', // افتراضياً لـ 4G
                'Code' => 'y4g_renew',
                'Category' => 'Yemen 4G',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],

            // 5. فواتير الماء والكهرباء
            [
                'Name' => 'تسديد مياه',
                'Prefixes' => null,
                'Code' => 'water_bill',
                'Category' => 'Utility Bills',
                'IsActive' => true,
                'DefaultProfit' => 0.00,
            ],
        ];

        foreach ($providers as $provider) {
            ServiceProvider::updateOrCreate(
                ['Code' => $provider['Code']],
                $provider
            );
        }
    }
}
