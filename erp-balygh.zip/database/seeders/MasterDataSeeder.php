<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class MasterDataSeeder extends Seeder
{
    public function run()
    {
        // 1. Branches (tblBranches)
        DB::table('tblBranches')->insertOrIgnore([
            ['ID' => 1, 'BranchName' => 'الإدارة', 'CreatedDate' => now()],
            ['ID' => 2, 'BranchName' => 'المركز الرئيسي', 'CreatedDate' => now()],
        ]);

        // 2. Account Types (tblAccountTypes)
        DB::table('tblAccountTypes')->insertOrIgnore([
            ['ID' => 1, 'AccountType' => 'رئيسي', 'CreatedDate' => now()],
            ['ID' => 2, 'AccountType' => 'فرعي', 'CreatedDate' => now()],
            ['ID' => 3, 'AccountType' => 'تفصيلي', 'CreatedDate' => now()],
            ['ID' => 4, 'AccountType' => 'عميل', 'CreatedDate' => now()],
            ['ID' => 5, 'AccountType' => 'مورد', 'CreatedDate' => now()],
        ]);

        // 3. Document Types (tblDocumentTypes)
        DB::table('tblDocumentTypes')->insertOrIgnore([
            ['ID' => 1, 'DocumentName' => 'سند قبض عملاء', 'TableName' => 'tblCustRecv', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 3, 'DocumentName' => 'سند صرف عملاء', 'TableName' => 'tblCustPay', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 4, 'DocumentName' => 'سند قيد بسيط', 'TableName' => 'tblSimpleEntries', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 5, 'DocumentName' => 'سند قيد مزدوج', 'TableName' => 'tblDblEntry', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 6, 'DocumentName' => 'شاشة المستخدمين', 'TableName' => 'tblUsers', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 7, 'DocumentName' => 'شراء عملة', 'TableName' => 'tblBuyCurrencies', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 8, 'DocumentName' => 'بيع عملة', 'TableName' => 'tblSellCurrencies', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 9, 'DocumentName' => 'كشف الحساب', 'TableName' => null, 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 10, 'DocumentName' => 'شاشة اسعار العملات', 'TableName' => 'tblCurrencies', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 11, 'DocumentName' => 'دليل الحسابات', 'TableName' => 'tblAccounts', 'IsActive' => 1, 'CreatedDate' => now()],
            ['ID' => 12, 'DocumentName' => 'شحن الرصيد', 'TableName' => 'tblRechargebalance', 'IsActive' => 1, 'CreatedDate' => now()],
        ]);

        // 4. Currencies (tblCurrencies)
        DB::table('tblCurrencies')->insertOrIgnore([
            ['ID' => 1, 'CurrencyName' => 'ريال يمني', 'EnglishCode' => 'YER', 'IsDefault' => 1, 'CreatedDate' => now()],
            ['ID' => 2, 'CurrencyName' => 'ريال سعودي', 'EnglishCode' => 'SAR', 'IsDefault' => 0, 'CreatedDate' => now()],
            ['ID' => 3, 'CurrencyName' => 'دولار أمريكي', 'EnglishCode' => 'USD', 'IsDefault' => 0, 'CreatedDate' => now()],
        ]);
    }
}
