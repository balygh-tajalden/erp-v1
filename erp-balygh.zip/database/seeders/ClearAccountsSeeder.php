<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClearAccountsSeeder extends Seeder
{
    public function run()
    {
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');
        DB::table('tblAccountBalances')->delete();
        DB::table('tblAccounts')->delete();
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
        $this->command->info('Accounts and Balances cleared successfully.');
    }
}
