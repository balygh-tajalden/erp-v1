<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Account;
use App\Models\AccountBalance;
use Illuminate\Support\Facades\DB;
use Exception;

class AccountImportSeeder extends Seeder
{
    public function run()
    {
        $csvPath = base_path('docs/ExportedD2ata.csv');
        if (!file_exists($csvPath)) {
            $this->command->error("CSV file not found at: {$csvPath}");
            return;
        }

        $file = fopen($csvPath, 'r');

        // Skip Header
        fgetcsv($file);

        $accounts = [];
        while (($row = fgetcsv($file)) !== false) {
            if ($row[3] === null || $row[3] === '') continue;

            $typeMap = [
                'رئيسي' => 1,
                'فرعي' => 2,
                'تفصيلى' => 3, 'تفصيلي' => 3,
                'عميل' => 4,
                'مورد' => 5
            ];

            // Map Final Account string to Legacy reference ID
            // الميزانية العمومية -> 1
            // حساب الأرباح والخسائر -> 2
            $refMap = [
                'الميزانية العمومية' => '1',
                'حساب الأرباح والخسائر' => '2'
            ];

            // Parse legacy date: "tt 00:00:00 01-01-2023"
            $rawDate = $row[7] ?? null;
            $formattedDate = now();
            if ($rawDate && strpos($rawDate, ' ') !== false) {
                try {
                    $parts = explode(' ', $rawDate);
                    $datePart = end($parts); // "01-01-2023"
                    $formattedDate = \Carbon\Carbon::createFromFormat('d-m-Y', $datePart)->startOfDay();
                } catch (\Exception $e) {}
            }

            $accounts[] = [
                'AccountName'      => $row[2],
                'AccountNumber'     => $row[3],
                'FatherNumber'      => $row[1],
                'AccountTypeID'     => $typeMap[$row[4]] ?? 1,
                'AccountReference'  => $refMap[$row[5]] ?? null,
                'BranchID'          => 2,
                'CreatedDate'       => $formattedDate,
                'CreatedBy'         => 1,
            ];
        }
        fclose($file);

        // Batch insert accounts using DB to maintain ID sequence or use updateOrCreate
        foreach (array_chunk($accounts, 100) as $chunk) {
            foreach ($chunk as $accountData) {
                $account = Account::updateOrCreate(
                    ['AccountNumber' => $accountData['AccountNumber']],
                    $accountData
                );

                // Initialize Balances for default currencies (1, 2, 3)
                foreach ([1, 2, 3] as $curId) {
                    AccountBalance::firstOrCreate([
                        'AccountID' => $account->ID,
                        'CurrencyID' => $curId,
                        'BranchID' => $account->BranchID,
                    ], ['Balance' => 0]);
                }
            }
        }

        $this->command->info("Imported " . count($accounts) . " accounts successfully.");
    }
}
